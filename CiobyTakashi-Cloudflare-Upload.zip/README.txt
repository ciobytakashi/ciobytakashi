CIOBYTAKASHI — STATIC WEBSITE STARTER
=====================================

Contents
- index.html: homepage
- categories/: three category landing pages
- about.html: About page
- affiliate-disclosure.html: affiliate disclosure
- privacy.html: starter privacy notice
- assets/css/styles.css: site styles
- assets/js/main.js: mobile navigation and current-year footer

DEPLOYMENT
Upload the contents of this folder (not the ZIP file itself) using Cloudflare Pages > Create application > Upload your static files. Keep index.html at the top level of the uploaded site folder.

IMPORTANT BEFORE PUBLIC LAUNCH
- This package contains no invented product reviews, testimonials, product claims, or affiliate URLs.
- The category pages intentionally show empty states until real researched articles are added.
- The privacy page is a general starter notice, not legal advice. Update it to match actual analytics, cookies, third-party embeds, contact methods, affiliate networks, and applicable legal requirements.
- No Amazon Associates participation is claimed. Apply to the program and add the required disclosure only if/when accepted.
- Cloudflare Pages static hosting can be used on its free plan within the current plan limits. Do not select a paid upgrade for this deployment.
